package com.cartItemService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CartitemserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
